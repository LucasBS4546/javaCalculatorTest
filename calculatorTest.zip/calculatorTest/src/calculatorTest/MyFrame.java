package calculatorTest;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class MyFrame extends JFrame implements ActionListener{
	
	JPanel displayArea;
	JPanel inputArea;
	
	JLabel displayer;
	JButton num1, num2, num3, num4, num5, num6, num7, num8, num9, num0, clearB; //number inputs
	JButton sumOp, subOp, mulOp, divOp, equOp; //operations
	
	JLabel numbers, operations;
	Integer firstNumber, secondNumber;
	int operationSwitch;
	double result;
	String numberDisplay, auxString, secondNumberString;
	
	boolean isSecondNumber;

	MyFrame(){

		numberDisplay = "";
		secondNumberString = "";
		isSecondNumber = false;
		operationSwitch = 0;
		/*
		 * OUTPUT
		 * */
		displayer = new JLabel();
		displayer.setBackground(Color.black);
		displayer.setForeground(Color.green);
		displayer.setOpaque(true);
		displayer.setText("0");
		displayer.setFont(new Font("Monospace", Font.PLAIN, 30));
		displayer.setBounds(42, 30, 300, 60);
		displayer.setVerticalAlignment(JLabel.CENTER);
		
		displayArea = new JPanel();
		displayArea.setBackground(Color.lightGray);
		displayArea.setBounds(0, 0, 400, 120);
		displayArea.setLayout(null);
		displayArea.add(displayer);
		
		/*
		 * INPUT
		 * */
		num1 = new JButton();
		num1.setBounds(10, 70, 60, 50);
		num1.setText("1");
		num1.addActionListener(this);
		
		num2 = new JButton();
		num2.setBounds(80, 70, 60, 50);
		num2.setText("2");
		num2.addActionListener(this);
		
		num3 = new JButton();
		num3.setBounds(150, 70, 60, 50);
		num3.setText("3");
		num3.addActionListener(this);
		
		num4 = new JButton();
		num4.setBounds(10, 130, 60, 50);
		num4.setText("4");
		num4.addActionListener(this);
		
		num5 = new JButton();
		num5.setBounds(80, 130, 60, 50);
		num5.setText("5");
		num5.addActionListener(this);
		
		num6 = new JButton();
		num6.setBounds(150, 130, 60, 50);
		num6.setText("6");
		num6.addActionListener(this);
		
		num7 = new JButton();
		num7.setBounds(10, 190, 60, 50);
		num7.setText("7");
		num7.addActionListener(this);
		
		num8 = new JButton();
		num8.setBounds(80, 190, 60, 50);
		num8.setText("8");
		num8.addActionListener(this);
		
		num9 = new JButton();
		num9.setBounds(150, 190, 60, 50);
		num9.setText("9");
		num9.addActionListener(this);
		
		num0 = new JButton();
		num0.setBounds(80, 250, 60, 50);
		num0.setText("0");
		num0.addActionListener(this);
		
		clearB = new JButton();
		clearB.setBounds(10, 10, 60, 50);
		clearB.setText("C");
		clearB.addActionListener(this);
		
		
		
		numbers = new JLabel();
		numbers.setLayout(null);
		numbers.setBounds(35,25,300,400);
		numbers.add(num1);
		numbers.add(num2);
		numbers.add(num3);
		numbers.add(num4);
		numbers.add(num4);
		numbers.add(num5);
		numbers.add(num6);
		numbers.add(num7);
		numbers.add(num8);
		numbers.add(num9);
		numbers.add(num0);
		numbers.add(clearB);
		
		
		sumOp = new JButton();
		sumOp.setBounds(0, 10, 60, 50);
		sumOp.setText("+");
		sumOp.setEnabled(false);
		sumOp.addActionListener(this);
		
		subOp = new JButton();
		subOp.setBounds(0, 70, 60, 50);
		subOp.setText("-");
		subOp.setEnabled(false);
		subOp.addActionListener(this);
		
		mulOp = new JButton();
		mulOp.setBounds(0, 130, 60, 50);
		mulOp.setText("*");
		mulOp.setEnabled(false);
		mulOp.addActionListener(this);
		
		divOp = new JButton();
		divOp.setBounds(0, 190, 60, 50);
		divOp.setText("/");
		divOp.setEnabled(false);
		divOp.addActionListener(this);
		
		equOp = new JButton();
		equOp.setBounds(0, 250, 60, 50);
		equOp.setText("=");
		equOp.setEnabled(false);
		equOp.addActionListener(this);
		
		
		operations = new JLabel();
		operations.setLayout(null);
		operations.setBounds(280, 25, 100, 400);
		operations.add(sumOp);
		operations.add(subOp);
		operations.add(mulOp);
		operations.add(divOp);
		operations.add(equOp);
		
		inputArea = new JPanel();
		inputArea.setBackground(new Color(220,220,220));
		inputArea.setBounds(0, 120, 400, 400);
		inputArea.setLayout(null);
		inputArea.add(numbers);
		inputArea.add(operations);
		
		
		this.setTitle("Calculator");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false);
		this.setLayout(null);
		this.setSize(400, 550);
		this.setVisible(true);
		this.add(displayArea);
		this.add(inputArea);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		boolean isEmpty = true;
		if(!isSecondNumber) {
			if(e.getSource()==num1) 
				numberDisplay += "1";
			
			if(e.getSource()==num2) 
				numberDisplay += "2";
			
			if(e.getSource()==num3) 
				numberDisplay += "3";
			
			if(e.getSource()==num4) 
				numberDisplay += "4";
			
			if(e.getSource()==num5) 
				numberDisplay += "5";
			
			if(e.getSource()==num6) 
				numberDisplay += "6";
			
			if(e.getSource()==num7) 
				numberDisplay += "7";
			
			if(e.getSource()==num8) 
				numberDisplay += "8";
			
			if(e.getSource()==num9) 
				numberDisplay += "9";
			
			if(e.getSource()==num0)
				numberDisplay += "0";
			
		} else {
			equOp.setEnabled(true);
			auxString = "";
			if(e.getSource()==num1) 
				auxString += "1";
			
			if(e.getSource()==num2) 
				auxString += "2";
			
			if(e.getSource()==num3) 
				auxString += "3";
			
			if(e.getSource()==num4) 
				auxString += "4";
			
			if(e.getSource()==num5) 
				auxString += "5";
			
			if(e.getSource()==num6) 
				auxString += "6";
			
			if(e.getSource()==num7) 
				auxString += "7";
			
			if(e.getSource()==num8) 
				auxString += "8";
			
			if(e.getSource()==num9) 
				auxString += "9";
			
			if(e.getSource()==num0)
				auxString += "0";
			secondNumberString += auxString;
			numberDisplay += auxString;
		}
		if(numberDisplay.length() > 0) {
			isEmpty = false;
			if(!isSecondNumber) {
				setEnableOperations(true);
			}		
		}
		if(!isEmpty){
			if(e.getSource()==sumOp) {
				firstNumber = Integer.parseInt(numberDisplay);
				numberDisplay += "+";
				setEnableOperations(false);
				isSecondNumber = true;
				operationSwitch = 1;
			}
			if(e.getSource()==subOp) {
				firstNumber = Integer.parseInt(numberDisplay);
				numberDisplay += "-";
				setEnableOperations(false);
				isSecondNumber = true;
				operationSwitch = 2;
			}
			if(e.getSource()==mulOp) {
				firstNumber = Integer.parseInt(numberDisplay);
				numberDisplay += "*";
				setEnableOperations(false);
				isSecondNumber = true;
				operationSwitch = 3;
			}
			if(e.getSource()==divOp) {
				firstNumber = Integer.parseInt(numberDisplay);
				numberDisplay+= "/";
				setEnableOperations(false);
				isSecondNumber = true;
				operationSwitch = 4;
			}
		}
		
		if(e.getSource()==equOp) {
			equOp.setEnabled(false);
			setEnableNumbers(false);
			secondNumber = Integer.parseInt(secondNumberString);
			switch(operationSwitch) {
			case 1:
				result = (double) firstNumber + secondNumber;
				break;
			case 2:
				result = (double) firstNumber - secondNumber;
				break;
			case 3:
				result = (double) firstNumber * secondNumber;
				break;
			case 4:
				result = (double) firstNumber / secondNumber;
				break;
			}
			numberDisplay += " = ";
			numberDisplay += result;
		}
		
		displayer.setText(numberDisplay);
		
		if(e.getSource()==clearB) {
			displayer.setText("0");
			numberDisplay = "";
			secondNumberString = "";
			isSecondNumber = false;
			operationSwitch = 0;
			equOp.setEnabled(false);
			setEnableOperations(false);
			setEnableNumbers(true);
		}	
		
	}
	
	void setEnableNumbers(boolean flag) {
		num1.setEnabled(flag);
		num2.setEnabled(flag);
		num3.setEnabled(flag);
		num4.setEnabled(flag);
		num5.setEnabled(flag);
		num6.setEnabled(flag);
		num7.setEnabled(flag);
		num8.setEnabled(flag);
		num9.setEnabled(flag);
		num0.setEnabled(flag);
	}
	
	void setEnableOperations(boolean flag) {
		sumOp.setEnabled(flag);
		subOp.setEnabled(flag);
		mulOp.setEnabled(flag);
		divOp.setEnabled(flag);
	}
	
}
